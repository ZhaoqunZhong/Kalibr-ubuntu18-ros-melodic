Test for MATLAB interface for CSparse.  Type "testall" to run all the tests.

Also includes "textbook" codes for the book "Direct Methods for Sparse Linear
Systems", which are not part of CSparse proper, but are used in the tests.

Timothy A. Davis, http://www.suitesparse.com
