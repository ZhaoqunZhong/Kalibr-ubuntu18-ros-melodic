function p = cs_maxtransr(A)                                                %#ok
%CS_MAXTRANSR recursive maximum matching algorithm
% Example:
%   p = cs_maxtransr(A)
% See also: cs_demo

% Copyright 2006-2012, Timothy A. Davis, http://www.suitesparse.com

error ('cs_maxtransr mexFunction not found') ;


